package com.MentorMitrAndroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import com.MentorMitrAndroid.IntroHelper.IntroActivity;
import com.MentorMitrAndroid.LoginHelperNew.LoginMobileNumberActivity;
import com.google.firebase.auth.FirebaseAuth;

public class SplashActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_acitivity);

        SharedPreferences sharedPreferences = getSharedPreferences("prefs", MODE_PRIVATE);

        int secondsDelayed = 1;
        new Handler().postDelayed(new Runnable() {
            public void run() {

                if(sharedPreferences.getBoolean("firstStart",true)){
                    Intent intent = new Intent(SplashActivity.this, IntroActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    if(FirebaseAuth.getInstance().getCurrentUser() != null){
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    else {
                        Intent intent = new Intent(SplashActivity.this, LoginMobileNumberActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }
        }, secondsDelayed * 1000);
    }
}